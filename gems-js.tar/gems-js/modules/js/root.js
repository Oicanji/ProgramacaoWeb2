gems = {}


